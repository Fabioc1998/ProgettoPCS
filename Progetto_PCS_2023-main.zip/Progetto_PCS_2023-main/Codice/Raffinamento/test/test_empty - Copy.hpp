#ifndef __TEST_EMPTY_H //Da riguardare
#define __TEST_EMPTY_H

#include <gtest/gtest.h>

#include "OggettiGeometrici_class.hpp"
#include "Mesh_class.hpp"

using namespace testing;

TEST(TestEmpty, TestEmpty)
{
 //
}

#endif // __TEST_EMPTY_H
